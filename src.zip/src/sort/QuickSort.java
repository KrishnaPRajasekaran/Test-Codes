package sort;

public class QuickSort {
static void quicksort(int a[],int low, int high)
{
//	int pivot=a[low+(high-low)/2];

	int i=low;
	int j=high;
	/*Concept is until i the number is less than pivot and until j it is greater than pivot
	 * So after i and j cross each other we stop and take low to j(which crossed i) and i(which crossed j) to high. Difference betweeen i and j is 1
	 * we add a return statement in the beginning because every recursive program should have a simple case with return else it will keep going. 
	 *  i can pick any element as the pivot element as long as it is within high and low
	 *  */
	if(i>=j)
		return;
	int pivot=a[low+1];
	while(i<=j)
	{
		while(a[i]<pivot)
		i++;
		while(a[j]>pivot)
		j--;
	
	//if(i<=j){
			System.out.println("swap"+i+" "+j);
		swap(a,i,j);
		i++;
		j--;
		
		for(int k=0;k<a.length;k++)
			System.out.format("%3d",a[k]);
		System.out.println();
	//	}
	}
	System.out.println("i"+i);
	System.out.println("j"+j);
	for(int k=0;k<a.length;k++)
		System.out.format("%3d",a[k]);
	System.out.println();
	quicksort(a,i,high);
	quicksort(a,low,j);
	}


static void swap(int a[],int i,int j)
{
	int temp;
	temp=a[i];
	a[i]=a[j];
	a[j]=temp;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]={5,6,3,4,1,0,9,5,8,3};
	// 0 6 3 4 1 5 9 5 8 3
		for(int k=0;k<a.length;k++)
			System.out.format("%3d",a[k]);
		System.out.println();
		
		//0 1 3 4 6
		quicksort(a,0,a.length-1);
		for(int i=0;i<a.length;i++)
			System.out.format("%3d",a[i]);
		System.out.println();
	
	}

}
