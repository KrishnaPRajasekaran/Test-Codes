package algorithms;

public class Knapsack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int weight[]={4,10,1,5,18};
int value[]={1,2,3,4};


	}

}
