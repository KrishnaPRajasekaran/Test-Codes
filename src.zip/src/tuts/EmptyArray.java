package tuts;
public class EmptyArray {
public static void main(String args[])
{
	int a[]=new int[0];
	System.out.println(a.length);

}
}
