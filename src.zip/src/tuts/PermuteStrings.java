package tuts;

public class PermuteStrings {
static void permute(char a[],int length){
	if(length==1)
		return; 
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
String input="abc";
char a[]=input.toCharArray();
permute(a,1);
	}

}
